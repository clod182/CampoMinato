compilare con : gcc -std=gnu89 -Wall -pedantic -o CampoMinato CampoMinato.c

Il passaggio in cui tornare indietro di n mosse quando si prede la mina non siamo riuciti ad implentarlo senza errori al momento, il giorno
dell'esposizione all'orale comunque faremo vedere quello che siamo riusciti a fare per questo problema il nostro ragionamento.
